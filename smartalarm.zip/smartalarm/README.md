smartalarm
==========

a simple Alarm Clock for android.
